# Usama SFTP 2.0 — feature and verification matrix

Independent, unlimited implementation of the supplied feature requirements. This does not modify the Utiltools extension or its subscription.

| Feature | Implementation / verification |
| --- | --- |
| Server setup | Workspace, name, protocol, host, port, user, password/key/agent, local/remote folders, ignore, default server, upload on save. Test Connection, Save, and remote folder browser exercised through the actual VS Code webview. |
| SFTP | Password and encrypted RSA private key authentication tested against a loopback SSH server. SSH agent support is implemented; a real running user agent is not available for an end-to-end test. |
| FTP / FTPS | Passive FTP, explicit FTPS, and implicit FTPS tested with authenticated binary uploads/downloads, replacement, remote editing, and file operations. Certificate validation stays enabled. A trusted fixture CA succeeds; an untrusted certificate fails. |
| Credential storage | Passwords and passphrases live in VS Code SecretStorage. Setup and legacy imports tested for absence of credential properties in project JSON. Private key paths and public fingerprints remain in JSON. |
| SSH host trust | First-use fingerprint approval; saved host fingerprints; changed/mismatched keys rejected. Configured fingerprint pinning and mismatch rejection tested. First-use approval requires the user to compare the fingerprint with their server. |
| Upload on save | Actual VS Code save event tested; only the active server receives the saved file. Ignored files and paths outside the local root are excluded. |
| Remote explorer | Lazy server tree, editable remote documents, download, diff, new file/folder, rename, delete, copy path, reveal local, upload here, active-server switch. File operations, spaces, Arabic names and stale-editor-save rejection tested. Destructive UI actions ask for confirmation. |
| No local mirror for remote editing | A server-only file is opened, edited and saved through the actual VS Code remote filesystem. Tests assert no matching local workspace file exists before opening, after opening and after saving, for all four protocol variants. Editor recovery data remains under VS Code's own control. |
| Two-way sync | SHA-256 content baselines distinguish one-sided changes, deletion, and conflicts. Preview performs no writes. Keep local/server/newer, bulk conflict choices, push/pull mirrors, optional deletions. Unresolved conflicts and stale previews block application. Local conflict choice, two-way changes, push mirrors, deletions and actual Preview/Apply buttons tested. Pull/conflict edge cases additionally covered by pure planner tests. |
| Git deploy | Working changes, untracked files, staged changes, changes since a ref, and saved last-deploy commit. Renames produce upload plus confirmed deletion. Actual temporary Git repository used to test working/ref previews, rename, add, delete and the deployment marker. |
| File manager | Separate local/server panes, navigation, file open/edit, new folder, rename, delete, diff, upload/download, drag between panes. F5 refresh, F2 rename, Enter open, Backspace parent, Delete remove, F6/F7 transfer. Actual UI upload/refresh and drag tested. Recursive transfers support changed destinations and empty folders. |
| Transfers | Two concurrent jobs, bytes, speed, status, cancel, retry, clear finished. Browse connections are separate from transfer connections. Actual authentication failure/retry and live SFTP cancellation tested; cancellation preserves the destination and cleans its temporary upload. |
| Import | Both `.vscode/sftp.json` and `.vscode/sftp-sync.json` accepted; legacy contexts, nested profiles and secrets migrated. Existing source file remains untouched. Imported upload-on-save is disabled until explicitly enabled. |
| Multi-root | Profiles stored per open workspace, active server and baseline stored in workspace state. Different servers may share the same local folder. Basic multi-server operation tested; large real-world multi-root projects not benchmarked. |
| SSH | Open SSH in Terminal uses the system SSH client; credentials are prompted by the client and never inserted into a command. The interactive shell itself requires a real SSH shell service. |
| SCP | Native SCP upload command opens a terminal. System SCP tested against a temporary pinned SSH host using a generated test key. Native clients use their own known-hosts files. |
| Rsync | Native Rsync preview command uses `--dry-run`; reports a missing executable clearly. Rsync is **not installed on this Windows system**, so real Rsync execution is not verified. Both sides also require Rsync for that optional workflow. |

Remote editor buffers are limited to 64 MB; uploads, downloads and sync hashing stream files. Recursive operations skip symbolic links. Sync tracks files, not empty-folder deletion. Portable replacement on servers without atomic rename briefly moves an existing file to a sibling backup before installing the completed upload; OpenSSH atomic rename is preferred when available.

No production host credentials were supplied, so testing used temporary local servers only. SSH shells, a running SSH agent, jump hosts, hardware keys, legacy SCP protocol and large-scale transfer performance have not been verified. No subscription, paywall, licensing endpoint, or transfer quota is present.
