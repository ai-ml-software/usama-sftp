const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const vscode = require('vscode');

async function bounded(label, promise) {
  console.log('Testing: ' + label);
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Timed out: ' + label)), 15000);
    })]);
  } finally { clearTimeout(timer); }
}
const execute = (command, ...args) => bounded(command, vscode.commands.executeCommand(command, ...args));

exports.run = async function () {
  const runRoot = process.env.USAMA_TEST_ROOT;
  const workspace = path.join(runRoot, 'workspace');
  const results = [];
  try {
    const extension = vscode.extensions.getExtension('usama.usama-sftp');
    assert.ok(extension, 'extension discovered');
    await bounded('activation', extension.activate());
    assert.equal(extension.isActive, true);
    const commands = new Set(await vscode.commands.getCommands(true));
    for (const { command } of extension.packageJSON.contributes.commands) {
      assert.ok(commands.has(command), `registered command ${command}`);
    }
    results.push('Activation and all contributed commands registered');
    await execute('usamaSftp.config');
    const configFile = path.join(workspace, '.vscode', 'usama-sftp.json');
    const config = JSON.parse(await fs.readFile(configFile, 'utf8'));
    assert.equal(config.uploadOnSave, false);
    assert.equal(config.protocol, 'sftp');
    const configs = JSON.parse(await fs.readFile(path.join(runRoot, 'server-configs.json'), 'utf8'));
    const document = await vscode.workspace.openTextDocument(vscode.Uri.file(configFile));
    const edit = new vscode.WorkspaceEdit();
    edit.replace(document.uri, new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length)),
      JSON.stringify(configs, null, 2));
    assert.equal(await vscode.workspace.applyEdit(edit), true);
    assert.equal(await document.save(), true);
    // The save event asynchronously rebuilds the server registry.
    await new Promise(resolve => setTimeout(resolve, 700));
    results.push('Config creation, save and multiple server loading');
    await execute('usamaSftp.servers.focus');
    await new Promise(resolve => setTimeout(resolve, 700));
    let remoteId = 0;
    for (const config of configs) {
      remoteId++;
      const local = path.join(workspace, config.name);
      const remote = path.join(runRoot, 'remote-' + config.name);
      const remoteUri = remotePath => vscode.Uri.parse('usama-sftp-remote://127.0.0.1:' + config.port +
        '/' + encodeURIComponent(remotePath.replace(/^\/+/, '')) + '?' +
        encodeURIComponent('remoteId=' + remoteId + '&fsPath=' + encodeURIComponent(remotePath)));
      await execute('usamaSftp.upload.file', vscode.Uri.file(path.join(local, 'upload.txt')));
      assert.deepEqual(await fs.readFile(path.join(remote, 'upload.txt')), await fs.readFile(path.join(local, 'upload.txt')));
      await execute('usamaSftp.download.file', vscode.Uri.file(path.join(local, 'download.txt')));
      assert.deepEqual(await fs.readFile(path.join(local, 'download.txt')), await fs.readFile(path.join(remote, 'download.txt')));
      results.push(config.name.toUpperCase() + ' authenticated upload and download, byte-for-byte');
      const preview = await bounded(config.name + ' preview', vscode.workspace.openTextDocument(remoteUri('/download.txt')));
      assert.equal(preview.getText(), await fs.readFile(path.join(remote, 'download.txt'), 'utf8'));
      const parent = { resource: { uri: remoteUri('/'), fsPath: '/' }, isDirectory: true };
      await execute('usamaSftp.create.folder', parent, undefined, 'folder with space');
      assert.equal((await fs.stat(path.join(remote, 'folder with space'))).isDirectory(), true);
      const folder = { resource: { uri: remoteUri('/folder with space'), fsPath: '/folder with space' }, isDirectory: true };
      await execute('usamaSftp.create.file', folder, undefined, 'ملف.txt');
      assert.equal((await fs.stat(path.join(remote, 'folder with space', 'ملف.txt'))).size, 0);
      const entry = { resource: { uri: remoteUri('/folder with space/ملف.txt'), fsPath: '/folder with space/ملف.txt' }, isDirectory: false };
      await execute('usamaSftp.renameRemote', entry, 'renamed.txt');
      assert.equal((await fs.stat(path.join(remote, 'folder with space', 'renamed.txt'))).isFile(), true);
      results.push(config.name.toUpperCase() + ' remote preview, create folder/file with spaces and Arabic, and rename');
    }
    await execute('usamaSftp.remoteExplorer.refresh');
    results.push('Server explorer refresh command');
    await fs.writeFile(path.join(runRoot, 'result.json'), JSON.stringify({ passed: true, results }, null, 2));
  } catch (error) {
    await fs.writeFile(path.join(runRoot, 'result.json'), JSON.stringify({ passed: false, results, error: error.stack }, null, 2));
    throw error;
  }
};
