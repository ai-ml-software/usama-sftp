param([string]$ProjectRoot, [string]$RunRoot, [string]$ExtensionRoot)
$ErrorActionPreference = 'Stop'
$env:USAMA_TEST_ROOT = $RunRoot
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
$codeExe = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'
if (-not $ExtensionRoot) { $ExtensionRoot = $ProjectRoot }
$arguments = @(
    '--new-window', '--skip-welcome', '--skip-release-notes', '--disable-workspace-trust',
    ('--user-data-dir="' + (Join-Path $RunRoot 'user-data') + '"'),
    ('--extensions-dir="' + (Join-Path $RunRoot 'extensions') + '"'),
    ('--extensionDevelopmentPath="' + $ExtensionRoot + '"'),
    ('--extensionTestsPath="' + (Join-Path $ProjectRoot 'tools\host-tests.cjs') + '"'),
    ('"' + (Join-Path $RunRoot 'workspace') + '"')
)
$hostProcess = Start-Process -FilePath $codeExe -ArgumentList $arguments -WindowStyle Hidden -PassThru -Wait `
    -RedirectStandardOutput (Join-Path $RunRoot 'host.stdout.log') `
    -RedirectStandardError (Join-Path $RunRoot 'host.stderr.log')
exit $hostProcess.ExitCode
