# Common configuration

## name
*string*: A string to identify your configuration.

## context
*string*: A path relative to the workspace root folder.
Use this when you want to map a subfolder to the `remotePath`.

**default**: The workspace root.

## protocol
*string*: `sftp` or `ftp`

**default**: `sftp`

## host
*string*: Hostname or IP address of the server.

## port
*integer*: Port number of the server.

**default**: 22

## username
*string*: Username for authentication.

## password
*string*: The password for password-based user authentication (**note: this is stored as plain-text**).

## remotePath
*string*: The absolute path on the remote host.

**default**: `/`

## filePerm
*number*: Set octal file permissions for new files.

**default**: false

## dirPerm
*number*: Set octal directory permissions for new directories.

**default**: false

## uploadOnSave
*boolean*: Upload on every save operation of VSCode.

**default**: false

## useTempFile
*boolean*: Upload temp file on every save operation of VSCode to avoid breaking a webpage when a user acceses it while the file is still being uploaded (is incomplete).

**default**: false

## openSsh
*boolean*: Enable atomic file uploads (only supported by openSSH servers).
If set to true, the `useTempFile` option must also be set to true.

**default**: false

## downloadOnOpen
*boolean*: Download the file from the remote server whenever it is opened.

**default**: false

## syncOption
*object*: Configure the behavior of the `Sync` command.

**default**: `{}`

## syncOption.delete
*boolean*: Delete extraneous files from destination directories.

## syncOption.skipCreate
*boolean*: Skip creating new files on the destination.

## syncOption.ignoreExisting
*boolean*: Skip updating files that exist on the destination.

## syncOption.update
*boolean*: Update the destination only if a newer version is on the source filesystem.

## ignore
*string[]*: Same behavior as gitignore, all paths relative to context of the current configuration.

**default**: []

## ignoreFile
*string*: Absolute path to the ignore file or relative path relative to the workspace root folder.

## watcher
*object*.

## watcher.files
*string*: Glob patterns that are watched and when edited outside of the VSCode editor are processed.
Set `uploadOnSave` to false when you watch everything.

## watcher.autoUpload
*boolean*: Upload when the file changed.

## watcher.autoDelete
*boolean*: Delete when the file is removed.

## remoteTimeOffsetInHours
*number*: The number of hours difference between the local machine and the remote server (remote minus local).

**default**: 0

## remoteExplorer
*object*.

## remoteExplorer.fileExclude
*string[]*: Configure that patterns for excluding files and folders.
The Remote Explorer decides which files and folders to show or hide based on this setting.

## remoteExplorer.order
*number*: Remote Explorer will ascending sorting by this value. If the values are the same, sort by name.

**default**: 0

## concurrency
*number*: Lowering the concurrency could get more stability because some clients/servers have some sort of configured/hard coded limit.

**default**: 4

## connectTimeout
*number*: The maximum connection time.

**default**: 10000

## limitOpenFilesOnRemote
*mixed*: Limit open file descriptors to the specific number in a remote server.
Set to true for using default `limit(222)`. Do not set this unless you have to.

**default**: false
