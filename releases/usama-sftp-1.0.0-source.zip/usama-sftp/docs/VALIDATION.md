# Usama SFTP validation

Validated locally on Windows on October 7, 2026, with Node 24.16.0 and Microsoft VS Code 1.141.0.

- `npm.cmd run check`: TypeScript check passed.
- `npm.cmd test -- --runInBand`: all 61 tests across six suites passed. Covers sync planning (including delete/update/time offsets/both directions), scheduling, configuration validation, imports without overwriting or enabling automatic actions, and remote names.
- `npm.cmd run compile`: production Webpack bundle passed.
- `npm.cmd run test:host`: actual VS Code extension activation and all contributed commands registered. Configuration creation/save and multiple server loading passed.
- Extension-host integration tested authenticated uploads/downloads byte-for-byte over SFTP, FTP, and explicit FTPS, remote text previews, creating folders with spaces and files with Arabic names, renaming remote files, and refreshing the explorer.
- Packaged VSIX installed successfully using the VS Code CLI; `code.cmd --list-extensions --show-versions` confirms `usama.usama-sftp@1.0.0`. Repeated the extension-host integration against the installed package, with all checks passing. The installed package contains all 42 contributed commands, the MIT/license notices and SSH2 1.17.0.
- FTPS used a locally generated trusted certificate and `rejectUnauthorized: true` on both control/data connections. Fixtures listened only on `127.0.0.1`, with disposable credentials and isolated local/remote file directories.

The test fixtures use Paramiko and pyftpdlib and are separate from the extension runtime. Install their dependencies into the project test folder before running transfer checks:

```powershell
python -m pip install --target .test-host/python-lib -r tools/loopback-requirements.txt
npm.cmd run compile
npm.cmd run test:host
```

Per-run logs and `result.json` remain under `.test-host/run-*`. The runner terminates fixture servers after testing. Test profiles disable updates and telemetry; the normal user profile and existing connection configurations are not used.

This is an MIT fork of Natizyskunk SFTP 1.16.3. It retains that extension's transfer architecture and configuration model. SSH jump hosts, key/agent/interactive authentication, implicit FTPS, external servers, Git upload, watcher actions, diff UI and every server-specific filesystem/permissions behavior have not all received live acceptance testing. The unit suite covers sync planning; live integration covers the operations listed above. No production server has been configured or connected.

Original copyrights are retained in LICENSE and the bundle/dependency license files. The proprietary Utiltools extension was not copied. Usama SFTP's unique commands, view IDs, settings, URI scheme and configuration filename allow it to coexist with installed SFTP extensions.
