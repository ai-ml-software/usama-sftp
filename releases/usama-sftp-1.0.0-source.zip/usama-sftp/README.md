# Usama SFTP

SFTP, FTP and FTPS servers inside Visual Studio Code. Local extension ID: `usama.usama-sftp`.

Open a project folder and click **Usama SFTP** in the activity bar. The **SFTP / FTP Servers** view lets you browse configured servers. Run **Usama SFTP: Config** from the command palette to create `.vscode/usama-sftp.json`.

```json
{
    "name": "My Server",
    "host": "your-server.example.com",
    "protocol": "sftp",
    "port": 22,
    "username": "your-user",
    "remotePath": "/public_html",
    "uploadOnSave": false,
    "ignore": ["**/.vscode/**", "**/.git/**", "**/.DS_Store"]
}
```

Replace the example connection details with your server's details and save. A password is requested when you connect if no password or key is configured. For SSH key authentication, add `"privateKeyPath": "C:/Users/Lenovo/.ssh/id_ed25519"` (using your actual key path). Passphrases and SSH agents are supported.

For FTP use `"protocol": "ftp", "port": 21`. For explicit FTPS add `"secure": true`; implicit FTPS uses `"secure": "implicit"` and your server's port. FTPS options are passed through `secureOptions`.

**Usama SFTP: Import SFTP Configuration** imports an existing `sftp.json` into the separate Usama configuration. It keeps the source unchanged, never overwrites an existing Usama configuration, and switches off automatic upload, download-on-open and watcher actions in imported configurations and profiles. Review and save the imported file to load the servers. Add your configuration file to your project's `.gitignore` if it contains credentials.

## Features

- Remote server tree, refresh, preview and edit files locally.
- Upload and download a file, selection, directory or project.
- Upload on save and optional file watcher uploads/deletes.
- Compare the active local file with its remote copy.
- Sync local to remote, remote to local, or both directions.
- Multiple servers, named profiles, switching profiles and transfer to all profiles.
- Create remote files/folders, rename remote entries, delete entries and copy remote paths.
- Upload changed Git files with `Ctrl+Alt+Shift+U`.
- SSH terminal, jump hosts, authentication with password/key/agent and interactive authentication.
- Ignore rules, concurrency, temporary uploads, transfer cancellation and a dedicated output/status channel.
- JSON schema validation and completion for `.vscode/usama-sftp.json`.

Store multiple servers as an array of configuration objects. Profiles can override fields within one configuration:

```json
{
    "name": "Application",
    "host": "staging.example.com",
    "username": "deploy",
    "remotePath": "/var/www/app",
    "protocol": "sftp",
    "uploadOnSave": false,
    "profiles": {
        "staging": { "host": "staging.example.com" },
        "production": { "host": "production.example.com" }
    },
    "defaultProfile": "staging"
}
```

Automatic transfers stay off until enabled in your configuration. Sync/delete commands perform real changes on your selected server; check the active profile and remote path before running them. Transfer progress and failures appear in the **Usama SFTP** output channel. Trusted workspaces are required.

## Install and build

Install the supplied VSIX using **Extensions > ... > Install from VSIX**, then reload the window. VS Code-compatible editors that support local VSIX installation may use the same artifact; they have not been tested here.

```powershell
npm.cmd ci --ignore-scripts
npm.cmd run check
npm.cmd test -- --runInBand
New-Item -ItemType Directory -Path releases -Force | Out-Null
npm.cmd run package
code.cmd --install-extension releases/usama-sftp-1.0.0.vsix --force
```

`npm.cmd run test:host` runs an isolated VS Code extension-host test with a temporary workspace. See [VALIDATION.md](docs/VALIDATION.md) for executed checks and their limits.

## Attribution

Usama SFTP is an independently branded MIT fork of [Natizyskunk/vscode-sftp](https://github.com/Natizyskunk/vscode-sftp), pinned to `v1.16.3`, commit `f44c554d19c35e812a9370eb0c3a4b975b3c6937`. The upstream copyright and MIT license remain in [LICENSE](LICENSE). The [original documentation](docs/UPSTREAM.md) is included for the inherited protocol/configuration features; its `sftp.*` commands and `sftp.json` paths correspond to Usama SFTP's `usamaSftp.*` commands and `usama-sftp.json` file.
